Phytec phyCORE-MPC5200-Tiny
===========================

Building the bootloader image for this target is covered by the ``pcm030_defconfig``.

Use the corresponding ``barebox.bin`` file for this target.
