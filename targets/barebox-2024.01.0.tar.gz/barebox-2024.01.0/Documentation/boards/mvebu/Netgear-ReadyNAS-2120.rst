Netgear ReadyNAS 2120
=====================

This is a rack mountable 4 bay NAS using an Armada XP dual-core processor.

UART booting
------------

The UART that can be used to boot via RS232 (using ``kwboot``) hides behind a
sticker on the backside of the machine. It uses TTL levels.
