Atmel AT91SAM9X5-EK Evaluation Kit
===================================

The AT91SAM9X5-EK kit supports Device Tree and Multi Images.

Building barebox:

.. code-block:: sh

  make ARCH=arm at91sam9x5ek_defconfig
