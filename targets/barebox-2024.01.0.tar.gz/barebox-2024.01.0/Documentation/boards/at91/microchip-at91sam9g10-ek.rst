Atmel AT91SAM9G10-EK Evaluation Kit
===================================

Building barebox:

.. code-block:: sh

  make ARCH=arm at91sam9g10ek_defconfig
