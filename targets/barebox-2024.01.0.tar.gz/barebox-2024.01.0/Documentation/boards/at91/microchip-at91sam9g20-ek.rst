Atmel AT91SAM9G20-EK Evaluation Kit
===================================

Building barebox:

.. code-block:: sh

  make ARCH=arm at91sam9g20ek_defconfig
