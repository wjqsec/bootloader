Atmel SAMA5D4 XPLAINED ULTRA Evaluation Kit
===========================================

Building barebox:

.. code-block:: sh

  make ARCH=arm sama5d4_xplained_defconfig
