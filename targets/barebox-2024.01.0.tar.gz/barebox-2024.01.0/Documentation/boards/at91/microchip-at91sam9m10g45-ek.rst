Atmel AT91SAM9M10G45-EK Evaluation Kit
======================================

Building barebox:

.. code-block:: sh

  make ARCH=arm at91sam9m10g45ek_defconfig
