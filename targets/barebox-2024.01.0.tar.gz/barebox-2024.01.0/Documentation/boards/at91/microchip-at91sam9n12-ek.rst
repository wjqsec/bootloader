Atmel AT91SAM9N12-EK Evaluation Kit
===================================

Building barebox:

.. code-block:: sh

  make ARCH=arm at91sam9n12ek_defconfig
