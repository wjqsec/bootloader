Atmel AT91RM9200-EK Evaluation Kit
==================================

Building barebox:

.. code-block:: sh

  make ARCH=arm at91rm9200ek_defconfig
