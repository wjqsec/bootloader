Atmel Telit EVK-PRO3
====================

Telit EVK-PRO3 with GE863-PRO3
Building barebox:

.. code-block:: sh

  make ARCH=arm telit_evk_pro3_defconfig
