Somfy Animeo IP
===============

No defconfig provided to build barebox
