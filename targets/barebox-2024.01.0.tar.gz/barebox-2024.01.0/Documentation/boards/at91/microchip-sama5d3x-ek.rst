Atmel SAMA5D3X Evaluation Kit
=============================

Building barebox:

.. code-block:: sh

  make ARCH=arm sama5d3xek_defconfig
