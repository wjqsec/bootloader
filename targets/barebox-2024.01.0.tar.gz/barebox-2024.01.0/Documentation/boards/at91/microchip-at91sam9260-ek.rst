Atmel AT91SAM9260-EK Evaluation Kit
===================================

Building barebox:

.. code-block:: sh

  make ARCH=arm at91sam9260ek_defconfig
