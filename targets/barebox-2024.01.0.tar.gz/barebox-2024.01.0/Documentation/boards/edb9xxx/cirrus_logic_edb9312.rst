Cirrus Logic EDB9312
====================

This board is based on a Cirrus Logic EP9312 CPU. The board is shipped with:

  * 32MiB NOR type Flash Memory
  * 64MiB synchronous dynamic RAM on CS3
  * 512kiB asynchronous SRAM
  * 128kiB serial EEPROM
  * MII 10/100 Ethernet PHY
  * Stereo audio codec
  * Real-Time Clock
  * IR receiver
