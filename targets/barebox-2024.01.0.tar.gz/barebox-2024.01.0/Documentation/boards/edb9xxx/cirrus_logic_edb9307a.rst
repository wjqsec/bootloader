Cirrus Logic EDB9307A
=====================

This board is based on a Cirrus Logic EP9307 CPU. The board is shipped with:

  * 32MiB NOR type Flash Memory
  * 64MiB synchronous dynamic RAM on CS0
  * 512kiB serial EEPROM
  * MII 10/100 Ethernet PHY
  * Stereo audio codec
  * Real-Time Clock
  * IR receiver

