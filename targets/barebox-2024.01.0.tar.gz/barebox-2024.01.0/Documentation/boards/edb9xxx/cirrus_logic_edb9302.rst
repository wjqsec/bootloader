Cirrus Logic EDB9302
====================

This board is based on a Cirrus Logic EP9302 CPU. The board is shipped with:

  * 16MiB NOR type Flash Memory
  * 32MiB synchronous dynamic RAM on CS3
  * 128kiB serial EEPROM
  * MII 10/100 Ethernet PHY
  * Stereo audio codec
