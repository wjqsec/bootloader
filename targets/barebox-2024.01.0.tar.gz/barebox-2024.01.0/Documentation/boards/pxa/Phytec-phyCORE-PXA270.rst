Phytec phyCORE-PXA270
=====================

Building the bootloader image for this target is covered by the ``phytec-phycore-pxa270_defconfig``.

Use the corresponding ``barebox.bin`` file for this target.
