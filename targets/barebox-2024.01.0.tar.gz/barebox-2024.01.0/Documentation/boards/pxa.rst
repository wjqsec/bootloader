PXA boards
----------

Not all supported boards have a description here.

.. toctree::
  :glob:
  :maxdepth: 1

  pxa/*
