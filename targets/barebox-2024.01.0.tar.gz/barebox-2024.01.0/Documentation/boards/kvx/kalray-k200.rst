Kalray K200
===========

This board is based on a MPPA3-80 SoC. The board is shipped with:

  - 128MiB NOR flash Memory
  - 8GiB DDR4 SDRAM
  - 2 x 100G Ethernet controllers supporting 8 x 1G, 10 and 25G
  - PCIe GEN4 X16 port

See https://www.kalrayinc.com/portfolio/boards/ for more information.
