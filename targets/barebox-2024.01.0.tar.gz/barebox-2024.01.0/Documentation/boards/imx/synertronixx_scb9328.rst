Synertronixx SCB9328
====================

See http://www.synertronixx.de/produkte/scb9328/scb9328.htm

This CPU card is based on a Freescale i.MX1 CPU. The card is shipped with:

  * 16MiB NOR type Flash Memory
  * 16MiB synchronous dynamic RAM
  * DM9000 network controller
