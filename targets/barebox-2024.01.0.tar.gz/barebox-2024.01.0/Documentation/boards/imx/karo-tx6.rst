Ka-Ro TX6x
==========

This CPU cards are based on a Freescale i.MX6 SoC.
There are currently six variants of this module, that are distinguished
by the suffix: 'Q' use an i.MX6Q and 'U' an i.MX6DL.

The TX6U-801x modules are shipped with:

  * 128MiB NAND flash
  * 1024MiB DDR3 SDRAM

see http://www.karo-electronics.de/tx6.html for more information
