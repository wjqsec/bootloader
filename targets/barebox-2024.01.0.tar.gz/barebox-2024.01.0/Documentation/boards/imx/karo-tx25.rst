Ka-Ro TX25
==========

Building the bootloader image for this target is covered by the ``multi_v5_v6_defconfig``
multiimage configuration if the ``System Type`` menu entry ``Ka-Ro TX25``
is enabled.

Use the corresponding ``barebox-karo-tx25.img`` for external NAND boot.
Use the corresponding ``barebox-karo-tx25-internal.img`` for internal NAND, USB
or SD card boot.
