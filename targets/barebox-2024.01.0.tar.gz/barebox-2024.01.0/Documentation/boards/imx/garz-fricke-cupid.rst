Garz+Fricke Cupid
=================

This CPU card is based on a Freescale i.MX35 CPU. The card is shipped with:

  * 256MiB NAND flash
  * 128MiB synchronous dynamic RAM

see http://www.garz-fricke.com/cupid-core_de.html for more information
