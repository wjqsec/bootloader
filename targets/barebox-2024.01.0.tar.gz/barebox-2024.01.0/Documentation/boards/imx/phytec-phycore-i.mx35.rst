Phytec phyCORE-i.MX35
=====================

Building the bootloader image for this target is covered by the ``phytec-phycore-imx35_defconfig``.

Use the corresponding ``barebox.bin`` file for this target. This image can be
used for booting in ``internal mode`` from NAND or NOR memory.
