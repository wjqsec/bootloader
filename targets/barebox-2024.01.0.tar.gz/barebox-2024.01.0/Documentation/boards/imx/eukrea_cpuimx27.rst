Eukrea CPUIMX27
===============

This CPU card is based on a Freescale i.MX27 CPU. The card is shipped with:

  * up to 64MiB NOR type Flash Memory
  * up to 256MiB synchronous dynamic RAM
  * up to 512MiB NAND type Flash Memory
  * MII 10/100 ethernet PHY
  * optional 16554 Quad UART on CS3

