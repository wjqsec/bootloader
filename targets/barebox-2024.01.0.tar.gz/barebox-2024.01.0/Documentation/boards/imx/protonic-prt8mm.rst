Protonic Holland PRT8MM board
=============================

This board is a low-cost 7inch touchscreen virtual terminal for agricultural applications.
HW specs:

* SoC: i.MX8M mini
* RAM: 1GiB LPDDR4
* eMMC: 16GiB
* Display: 7inch 800x480 with capacitive touchscreen.
