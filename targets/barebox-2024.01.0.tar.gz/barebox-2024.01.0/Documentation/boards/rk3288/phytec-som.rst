Phytec RK3288 based SOMs
========================

The phycore-som-rk3288 is actually not a real board. It represents a RK3288
based Phytec module and its boards in the barebox.
You can find out more about the Phytec SOM concept on the website:

  http://phytec.com/products/system-on-modules/


Supported modules and boards
----------------------------

Currently, barebox supports the following SOMs and boards:

  - phyCORE

    - PCM-946
    - PCM-947

Building phycore-som-rk3288
---------------------------

The phycore-som-rk3288 boards are covered by the ``rk3288_defconfig``.
