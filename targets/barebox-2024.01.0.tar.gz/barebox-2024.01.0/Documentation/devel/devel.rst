.. highlight:: console

barebox programming
===================

Contents:

.. toctree::
   :maxdepth: 2

   porting
   background-execution
   project-ideas

* :ref:`search`
* :ref:`genindex`
