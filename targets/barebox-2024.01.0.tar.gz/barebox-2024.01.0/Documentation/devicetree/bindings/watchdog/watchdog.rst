Watchdogs
=========

In addition to the upstream bindings, following properties are understood:

Optional properties:

- ``watchdog-priority`` : Overrides the priority set by the driver. Normally,
  the watchdog device with the biggest reach should reset the system.
  See :ref:`system_reset` for more information.
