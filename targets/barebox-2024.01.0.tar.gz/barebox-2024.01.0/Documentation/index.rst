.. barebox documentation master file, created by
   sphinx-quickstart on Tue Jun 17 11:45:57 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to barebox
==================

Contents:

.. toctree::
   :glob:
   :numbered:
   :maxdepth: 1

   user/user-manual
   filesystems
   commands
   boards
   glossary
   devicetree/*
   devel/devel.rst
   talks

* :ref:`search`
* :ref:`genindex`

