// SPDX-License-Identifier: GPL-2.0-or-later
// SPDX-FileCopyrightText: 2012 Free Electrons

#ifndef __HWDETECT_H__
#define __HWDETECT_H__

void cfa10036_detect_hw(void);

#endif /* __HWDETECT_H__ */
