/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef PHYBOARD_POLIS_RDK_LOWLEVEL_H_
#define PHYBOARD_POLIS_RDK_LOWLEVEL_H_

extern struct dram_timing_info phyboard_polis_rdk_dram_timing;

#endif
