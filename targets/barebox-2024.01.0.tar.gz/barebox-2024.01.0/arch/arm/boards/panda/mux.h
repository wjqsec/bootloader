/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef __BOARD_MUX_H
#define __BOARD_MUX_H

void panda_set_muxconf_regs(void);

#endif /* __BOARD_MUX_H */
