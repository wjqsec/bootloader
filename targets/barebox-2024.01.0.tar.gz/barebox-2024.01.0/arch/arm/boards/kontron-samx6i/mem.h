/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef __BOARD_KONTRON_SAMX6I_MEM_H
#define __BOARD_KONTRON_SAMX6I_MEM_H

resource_size_t samx6i_get_size(void);

#endif /* __BOARD_KONTRON_SAMX6I_MEM_H */
