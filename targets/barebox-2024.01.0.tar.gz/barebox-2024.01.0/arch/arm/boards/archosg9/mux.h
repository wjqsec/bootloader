/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef _MUX_H
#define _MUX_H

void archosg9_set_muxconf_regs(void);

#endif /* _MUX_H */
