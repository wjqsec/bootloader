/* SPDX-License-Identifier: GPL-2.0-only */

void base_board_init(void);

