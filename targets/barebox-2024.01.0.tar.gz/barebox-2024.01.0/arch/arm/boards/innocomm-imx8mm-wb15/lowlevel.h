/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef INNOCOMM_WB15_LOWLEVEL_H_
#define INNOCOMM_WB15_LOWLEVEL_H_

void innocomm_wb15_power_init_board(void);
extern struct dram_timing_info innocomm_wb15_dram_timing;

#endif
